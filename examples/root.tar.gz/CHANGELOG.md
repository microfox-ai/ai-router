# next-perplexity-clone

## 0.1.2

### Patch Changes

- Updated dependencies [07d4a18]
- Updated dependencies [2a62227]
- Updated dependencies [58300f5]
  - @microfox/ai-router@2.1.0

## 0.1.2-beta.0

### Patch Changes

- Updated dependencies [07d4a18]
  - @microfox/ai-router@2.0.1-beta.0

## 0.1.1

### Patch Changes

- Updated dependencies [3dc4cc4]
  - @microfox/ai-router@2.0.0
