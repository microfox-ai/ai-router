# next-perplexity-clone

## 0.1.1

### Patch Changes

- Updated dependencies [3dc4cc4]
  - @microfox/ai-router@2.0.0
