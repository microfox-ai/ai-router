
export default function RequestWindow() {
  return (
    <div>
      <h1>Home</h1>
    </div>
  );
}
