

export const SummarizeFull = () => {
  return <div>SummarizeFull</div>;
};